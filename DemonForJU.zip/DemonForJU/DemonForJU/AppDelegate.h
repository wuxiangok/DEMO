//
//  AppDelegate.h
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
