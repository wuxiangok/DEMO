//
//  CityDetailView.m
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import "CityDetailView.h"

@interface CityDetailView ()

@end

@implementation CityDetailView
@synthesize _cityString;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 100, 40)];
    lable.text = self._cityString;
    lable.backgroundColor = [UIColor blueColor];
    [self.view addSubview:lable];
    [lable release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [_cityString release];
    [super dealloc];
}
@end
