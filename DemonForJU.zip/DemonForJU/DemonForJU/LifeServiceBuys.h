//
//  LifeServiceBuys.h
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LifeServiceBuys : UIViewController

@property(nonatomic,retain)NSMutableArray *_storeArray;
@property(nonatomic,retain)IBOutlet UITableView *_tableView;
@property(nonatomic,retain)IBOutlet UIActivityIndicatorView *_active;
@end
