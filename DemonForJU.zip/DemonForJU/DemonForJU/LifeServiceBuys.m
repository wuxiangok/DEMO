//
//  LifeServiceBuys.m
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import "LifeServiceBuys.h"
#import "CJSONDeserializer.h"
#import "WebAPI.h"
#import "CityDetailView.h"

@interface LifeServiceBuys ()

@end

@implementation LifeServiceBuys
@synthesize _storeArray;
@synthesize _tableView;
@synthesize _active;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        [self initData];
    }
    return self;
}

- (void)initData
{
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:0];
    self._storeArray = array;
    [array release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getNetWorkData];
}

- (void)getNetWorkData
{
    [self._active startAnimating];
    [self._active setHidden:NO];
    dispatch_async(dispatch_get_global_queue(2, 0), ^{
       NSString *url = @"http://gw.api.tbsandbox.com/router/rest?sign=374C2D167C9E9D4A1DD7B295D698D5F5&timestamp=2013-08-18+21%3A30%3A53&v=2.0&app_key=1012129701&method=taobao.ju.cities.get&partner_id=top-apitools&format=json";
       NSString *jsonStr = httpBasicGetMethod(url);
       dispatch_async(dispatch_get_main_queue(), ^{
           [self._active stopAnimating];
           [self._active setHidden:YES];
           NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
           NSError *error;
           NSMutableDictionary *root = [[CJSONDeserializer deserializer] deserialize:jsonData error:&error];
           NSMutableDictionary *cityDic = (NSMutableDictionary *)[root objectForKey:@"ju_cities_get_response"];
           NSMutableDictionary *strDic = (NSMutableDictionary *)[cityDic objectForKey:@"cities"];
           NSMutableArray *array = (NSMutableArray *)[strDic objectForKey:@"string"];
           self._storeArray = array;
           [self._tableView reloadData];
       });
   });
}

#pragma mark -
#pragma mark - tableView methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_storeArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = [indexPath row];
    
    static NSString *identifer = @"_defaultCell_";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifer];
    if(!cell)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifer] autorelease];
    }
    cell.textLabel.text = [self._storeArray objectAtIndex:row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    NSInteger row = [indexPath row];
     if([_storeArray count]>row)
     {
         NSString *cityStr = [_storeArray objectAtIndex:row];
         if([cityStr length])
         {
             CityDetailView *city = [[CityDetailView alloc] initWithNibName:@"CityDetailView" bundle:nil];
             if(city)
             {
                 city._cityString = cityStr;
             }
             [self.navigationController pushViewController:city animated:YES];
         }
     }
}

- (void)dealloc
{
    [_storeArray release];
    [_tableView release];
    [_active release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
