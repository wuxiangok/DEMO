//
//  RandomGoodsBuys.h
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RandomGoodsBuys : UIViewController

@end
