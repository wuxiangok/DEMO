//
//  ViewController.m
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import "ViewController.h"
#import "OrdinaryGoodsBuys.h"
#import "LifeServiceBuys.h"
#import "RandomGoodsBuys.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSArray *array = [NSArray arrayWithObjects:@"OrdinaryGoodsBuys",@"LifeServiceBuys",@"RandomGoodsBuys",nil];
	for (int i=0; i<3; i++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [button setFrame:CGRectMake(10, 100+i*70, 300, 44)];
        [button setTag:i];
        [button setTitle:[array objectAtIndex:i] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(showPages:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
    }
}

- (void)showPages:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    switch (btn.tag)
    {
        case 0:
        {
            OrdinaryGoodsBuys *ordinary = [[OrdinaryGoodsBuys alloc] initWithNibName:@"OrdinaryGoodsBuys" bundle:nil];
            if(ordinary)
            {
                [self.navigationController pushViewController:ordinary animated:YES];
            }
            break;
        }
        case 1:
        {
            LifeServiceBuys *lifeService = [[LifeServiceBuys alloc] initWithNibName:@"LifeServiceBuys" bundle:nil];
            if(lifeService)
            {
                [self.navigationController pushViewController:lifeService animated:YES];
            }
            break;
        }
        case 2:
        {
            RandomGoodsBuys *randomGoods = [[RandomGoodsBuys alloc]initWithNibName:@"RandomGoodsBuys" bundle:nil];
            if(randomGoods)
            {
                [self.navigationController pushViewController:randomGoods animated:YES];
            }
            break;
        }
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
