//
//  WebAPI.h
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebAPI : NSObject

//////////////////////////////////////////////////////////////////////////////////////////////////
/**
 http基础接口
 */
NSString * httpBasicGetMethod(NSString *url);
NSString * httpBasicPostMethod(NSString *url ,NSString * postData);

@end

