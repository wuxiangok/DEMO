//
//  WebAPI.m
//  DemonForJU
//
//  Created by wsz on 13-8-18.
//  Copyright (c) 2013年 wsz. All rights reserved.
//

#import "WebAPI.h"

@implementation WebAPI

#pragma mark
#pragma mark http基础接口
//////////////////////////////////////////////////////////////////////////////////////////////////
/**
 普通Get请求
 */
NSString * httpBasicGetMethod(NSString *url)
{
    NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:[NSURL URLWithString:url]];
	[request setHTTPMethod:@"GET"];
    [request setTimeoutInterval:15.0];
    
	NSHTTPURLResponse * response;
	NSData* data = [NSURLConnection sendSynchronousRequest:request
										 returningResponse:&response error:nil];
    if ([response statusCode]==200)
    {
        return [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    }
	else
    {
        return nil;
    }
    return nil;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
/**
 普通Post请求
 */
NSString * httpBasicPostMethod(NSString *url ,NSString * postData)
{
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:[NSURL URLWithString:url]];
    
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	[request setHTTPMethod:@"POST"];
	[request setTimeoutInterval:15.0];
	NSHTTPURLResponse * response;
	NSData *urlData;
	NSError *error;
	
	urlData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    if ([response statusCode]==200)
    {
        return  [[[NSString alloc] initWithData:urlData encoding:NSUTF8StringEncoding] autorelease];
    }
	else
    {
        return nil;
    }
}

@end
